/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.apptest;

/**
 *
 * @author Student
 */
public class AppTest {

    public static void main(String[] args) {
       using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace YourApp.Tests
{
    [TestClass]
    public class ProductCalculationsTests
    {
        [TestMethod]
        public void GetVat_WithValidData_ReturnsCorrectValue()
        {
            // Arrange: price 100 x qty 2 = 200 subtotal, 10% commission
            IProductCalculations calc = new ProductCalculations(100, 2, 0.10);
            double expected = 30;   // 200 * 0.15

            // Act
            double actual = calc.GetVat();

            // Assert
            Assert.AreEqual(expected, actual, 0.001);
        }
    }
}
    }
}
