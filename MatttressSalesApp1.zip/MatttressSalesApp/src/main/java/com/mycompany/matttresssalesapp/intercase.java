/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matttresssalesapp;

/**
 *
 * @author Student
 */
public class intercase {
    // IProductCalculations.cs
public interface IProductCalculations
{
    double GetVat();
    double GetCommission();
    double GetTotal();
}
}

// ProductCalculations.cs
public class ProductCalculations : IProductCalculations
{
    private const double VatRate = 0.15;

    private readonly double _price;
    private readonly int _quantity;
    private readonly double _commissionRate;

    public ProductCalculations(double price, int quantity, double commissionRate)
    {
        _price = price;
        _quantity = quantity;
        _commissionRate = commissionRate;
    }

    private double SubTotal() => _price * _quantity;

    public double GetVat() => SubTotal() * VatRate;

    public double GetCommission() => SubTotal() * _commissionRate;

    public double GetTotal() => SubTotal() + GetVat() + GetCommission();
}