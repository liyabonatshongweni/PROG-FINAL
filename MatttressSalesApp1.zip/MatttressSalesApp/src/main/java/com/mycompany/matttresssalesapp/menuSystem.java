/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.matttresssalesapp;

/**
 *
 * @author Student
 */
public interface menuSystem {
    private void btnProcess_Click(object sender, EventArgs e)
{
    ProcessSale();
}

private void exitToolStripMenuItem_Click(object sender, EventArgs e)
{
    Application.Exit();
}

private void processToolStripMenuItem_Click(object sender, EventArgs e)
{
    ProcessSale();   // same logic as the Process button
}

private void clearToolStripMenuItem_Click(object sender, EventArgs e)
{
    txtPrice.Clear();
    txtQuantity.Clear();
    cmbCategory.SelectedIndex = 0;
}

// Shared logic used by both the button and the menu item
private void ProcessSale()
{
    if (!double.TryParse(txtPrice.Text, out double price) ||
        !int.TryParse(txtQuantity.Text, out int quantity))
    {
        MessageBox.Show("Please enter valid numeric values.");
        return;
    }

    double rate;
    switch (cmbCategory.SelectedIndex)
    {
        case 1: rate = 0.05; break;
        case 2: rate = 0.10; break;
        case 3: rate = 0.15; break;
        default:
            MessageBox.Show("Please select a category.");
            return;
    }

    IProductCalculations calc = new ProductCalculations(price, quantity, rate);

    lblResult.Text = $"VAT: {calc.GetVat():C}\n" +
                     $"Commission: {calc.GetCommission():C}\n" +
                     $"Total: {calc.GetTotal():C}";
}
}
