/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matttresssalesapp;

import javax.swing.JOptionPane;

/**
 *
 * @author Student
 */
public class MatttressSalesApp extends JFrame{

    public static void main(String[] args) {
         
        //Declare GUI Components
        private JTextField txtCustomer;
        private JComboBox<String>cmbProduct;
        private JTextField txtPrice;
        private JButton btnProcess;
        
        //Constructor
        public MattresSalesApp(){
            setTitle("Mattress Sales Application ");
            setSize("450, 300");
            
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            setLocationRelativeTo(null);
            setLayout(new GridLayout(5, 2, 10,10));
            
            //Customer Name
            add(new JLabel("Customer Name: "));
            String[]product={
                "Cozy Nights Monarch",
                "Restonic Barbados",
                "Sealy Phuket"
            };
            
            cmbProduct = new
                JComboBox<>(products);
            add(cmbProduct);
            
            //Product Price
            add(new JLabel("Enter Price (R):"));
            
            txtPrice = new JTextField();
            add(txtPrice);
            
            btnProcess = new JButton("PROCESS ");
            add(btnProcess);
            
            //Button Action
            btnProcess.addActionListener(new ActionListener()){
           @Override
           public void
                   actionPerformed(ActionEvent){ProcessSales();}
                   
                setVisible(true);   
             }
            //Method to process Sales
            private void processSales(){
                try{
                    //capture Customer details
                    String Customer details
                            String customerName =txtCustomer.getText().trim();
                            
                            //Capture product price
                            if (customerName.isEmpty()){
                                JOPTIONpANE.ShowMassageDialog(this,"Please enter the customer name.");
                                
                                return;
                            }
                            double price = Double.parseDouble(txtPrice.getText().trim());
                            if(!Double.isFinite(price)||price <=0){
                                JOptionPane.showMassageDialog(this,"Please enter enter a valid price greater than zero ");
                                
                                return
                                        }
                            //calculate VAT and Commission
                            double total = price *0.15;
                            double commission = price*0.05;
                            
                            // Calculate Total Sales
                            String result = "Customer Name: + customerName+ "\nProduct: R"+ productName+ "\nVAT:R" + String.format("%2f",vat) + "\nTOTAL:R +"String.format("%2f", total); JOtionPane.showMessageDialog(this, result,"Sales Information ",
                           JOptionPane.INFORMATION_MESSAGE);
                           
                           //sAVE INFORMATION TO DATA.TXT
                           saveToFile(customerName, productName, vat, commission, total );
                }catch (NumberFormatExcetion ex){
                    JOptionPane.showMasageDialog(this,"Please enter a valid numerical price ");
                    
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(this, "An error occured: ")+ ex.getMessage()
                            );
                }
                            }
            }//Method to save information to a file
               private void save saveToFile(Strting customer,
                                            String product, 
                                            double vat,
                                            double total){
                       try(FileWriter writer = new Writer("data.txt",true)){
                     writer.wtite("DATA LOG\n");
                writer.write(******\n);
          
writer.write("Customer Name: "+ customer +"\n");
writer.write("Product: "+ product+ "\n");
wtiter.write("VAT":R +String.format("%.2f",commission) +"\n");
}
}
    }
}
